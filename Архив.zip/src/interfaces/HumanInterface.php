<?php


    interface HumanInterface
    {
        public function sayHello();

        public function getName();

        public function setName($name);

    }