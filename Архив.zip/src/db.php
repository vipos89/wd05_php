<?php
    $connection = mysqli_connect('mysql', 'root', 'root', 'wd05');


