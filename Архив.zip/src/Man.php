<?php


    abstract class Man extends Person
    {

        public function ololo2($name)
        {
            // TODO: Implement ololo2() method.
        }

    }