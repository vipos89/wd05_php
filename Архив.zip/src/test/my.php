<?php
    echo __DIR__;
    echo "<br>";
    echo __FILE__;
    ///var/www/html/test
    include_once __DIR__.'/../test2/my2.php';
