<?php

    include 'my_functions.php';
    setcookie('my_cookie', 'ololo222', time()+60*60*24*30 );
    $aaaaaa = 1;
    $b = 4;

    echo sum(a:1111, c:111, b:9999);

    //sum(1, 4444);





