<?php


    abstract class Person
    {
        final public function ololo()
        {
            //fhfhgfhhfhhhfhg
        }

        abstract public function ololo2($name);
        abstract public function ololo3();

    }